import { expect } from "chai";

describe("Delete User using Reqres API"), () => {
    it("should delete a user", async () => {
        const response = await fetch("https://reqres.in/api/users/2", {
            method: "DEL",
            headers: {
                "x-api-key": "reqres-free-v1",
                "accept": "application/json",
            },
        });
        const data = await response.json();
        console.log(data);
        expect(response.status).to.equal(204);
    });
};