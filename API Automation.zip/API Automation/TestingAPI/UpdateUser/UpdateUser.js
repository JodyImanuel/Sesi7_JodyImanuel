import { expect } from "chai";

describe("Update User using Reqres API"), () => {
    it("should update a user", async () => {
        const response = await fetch("https://reqres.in/api/users/2", {
            method: "PATCH",
            headers: {
                "x-api-key": "reqres-free-v1",
                "accept": "application/json",
            },
        });
        const data = await response.json();
        console.log(data);
        expect(response.status).to.equal(200);
    });
};