import { expect } from "chai";

describe("Get User List using Reqres API"), () => {
    it("should get a user", async () => {
        const response = await fetch("https://reqres.in/api/unknown", {
            method: "GET",
            headers: {
                "x-api-key": "reqres-free-v1",
                "accept": "application/json",
            },
        });
        const data = await response.json();
        console.log(data);
        expect(response.status).to.equal(200);
    });
};