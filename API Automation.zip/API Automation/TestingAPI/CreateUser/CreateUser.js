import { expect } from "chai";

describe("Create User using Reqres API"), () => {
    it("should create a user", async () => {
        const response = await fetch("https://reqres.in/api/users", {
            method: "POST",
            headers: {
                "x-api-key": "reqres-free-v1",
                "accept": "application/json",
            },
            body: {
                "name": "Jody Imanuel",
                "job": "Senior QA Tokopedia",
                "hoby": "Basketball",
                "email": "jodyimanuel@gmail.com"
            }
        });
        const data = await response.json();
        console.log(data);
        expect(response.status).to.equal(200);
        expect(response.name).to.include("Jody Imanuel")
    });
};